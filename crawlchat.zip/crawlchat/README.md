# CrawlChat — CLI-Driven AI Chat Execution (BuildSprint Round 2)

A chat app that turns a plain-English request ("Crawl https://example.com, summarise it and return JSON")
into a **controlled CLI execution**: the backend validates the task, launches an approved crawler CLI,
captures its output/exit code, validates the result, and shows a summary + valid JSON in the chat —
or an honest error / partial status.

## Architecture
```
Browser chat UI ──POST /api/chat (NDJSON stream)──► Node backend (server.js)
   1. Intent layer      LLM (optional) or rule-based parser → strict-schema task spec
   2. Validation        URL scheme/port/credentials, DNS + private-IP (SSRF) block, caps on pages/depth
   3. Orchestration     allow-listed tool registry → spawn("python", ["-I","crawler.py", ...args]) (no shell)
   4. CLI: site-crawler (crawler/crawler.py) — robots.txt, same-domain, page/depth/size/time limits
   5. Output capture    stdout (streamed live), stderr, exit code, JSON result file
   6. Result layer      schema-validate → summarise (LLM or extractive) → chat JSON/summary + status badge
```
**Why a Python stdlib CLI?** Zero install, easy to sandbox, deterministic, and cleanly separated from the
LLM: the model only chooses parameters, it never writes commands. The registry in `server.js` (`TOOLS`) makes
it easy to add more approved CLIs.

Exit codes: `0` success · `2` partial · `3` failed · `4` invalid/blocked target.

## Prerequisites
Node.js ≥ 18 and Python ≥ 3.8. No `npm install` / `pip install` needed.

## Run
```bash
cp .env.example .env      # optional: add ANTHROPIC_API_KEY or GEMINI_API_KEY
node server.js            # open http://localhost:3000
```
Demo prompt: `Crawl https://example.com, extract the important information, give me a summary, and return the extracted data in JSON format.`

Without an API key everything still works (rule-based intent parsing + extractive summary); with a key the
LLM parses intent and writes the summary. The UI shows which one was used.

## Tests (real execution, no mocks)
```bash
node test/run_tests.js
```
Starts a local test website (with robots.txt and a page containing prompt-injection text) and checks: success/partial
flow, valid JSON, robots.txt, same-domain only, unsupported request, invalid URL, 404, hanging site → timeout,
non-http scheme. (The test sets `ALLOW_PRIVATE_TARGETS=1` solely so it can crawl localhost.)

## Security measures
- No shell, no raw text in commands: only validated values go into a fixed argv array; only allow-listed tool.
- URL validation: http/https only, no embedded credentials, port allow-list, DNS resolved and private/loopback/link-local/metadata IPs blocked (re-checked inside the CLI on every redirect).
- Respectful crawling: robots.txt honoured, same-domain only, max pages ≤ 25, depth ≤ 3, 1 MB/page, HTML only, per-request + total timeout, delay between requests. No auth bypass.
- Website content is untrusted data: parsed as text only (scripts/styles stripped), rendered with `textContent` (no HTML injection), wrapped in delimiters with an explicit "do not follow instructions" system prompt for the LLM, and it can never trigger a command.
- Child process gets a minimal environment (no API keys); secrets are redacted from logs/chat; `.env` is git-ignored.
- Rate limit (6 req/min/IP), concurrency cap (2), request-size cap, cancellation (Stop button kills the process), SIGKILL on timeout.
- Honest status: success only when the CLI produced a schema-valid result; partial/failed are labelled clearly.

## AI tools disclosure
Built with AI coding assistance (Claude) for scaffolding, tests and docs; I reviewed and can explain every part.
Runtime LLM (optional): Anthropic Claude or Google Gemini API.

## Project layout
`server.js` backend · `crawler/crawler.py` CLI · `public/index.html` chat UI · `test/` end-to-end tests
