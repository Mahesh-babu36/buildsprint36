// End-to-end tests: starts a local test website + the CrawlChat server, sends real chat requests.
// Run: node test/run_tests.js     (no API key needed)
process.env.ALLOW_PRIVATE_TARGETS = "1"; // ONLY so the test can crawl localhost
process.env.PORT = "3999";
process.env.CLI_TIMEOUT_MS = "8000";
const http = require("http"), path = require("path"), fs = require("fs");
const { spawn } = require("child_process");
const { server } = require("../server.js");

const site = http.createServer((req, res) => {
  const f = path.join(__dirname, "site", req.url === "/" ? "index.html" : req.url.slice(1));
  if (req.url === "/slow") return setTimeout(() => res.end("<html>slow</html>"), 60000);
  fs.readFile(f, (e, d) => { if (e) { res.writeHead(404).end("nf"); } else { res.writeHead(200, { "content-type": f.endsWith(".txt") ? "text/plain" : "text/html" }); res.end(d); } });
});

async function chat(message) {
  const r = await fetch("http://127.0.0.1:3999/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message }) });
  const lines = (await r.text()).trim().split("\n").map((l) => JSON.parse(l));
  return { events: lines, final: lines.find((l) => l.type === "final") };
}
let pass = 0, fail = 0;
const check = (name, cond, extra = "") => { (cond ? pass++ : fail++); console.log((cond ? "PASS " : "FAIL ") + name + (cond ? "" : "  " + extra)); };

(async () => {
  await new Promise((r) => site.listen(8765, "127.0.0.1", r));
  await new Promise((r) => server.listen(3999, "127.0.0.1", r));

  let { final, events } = await chat("Crawl http://127.0.0.1:8765/, extract the important information, give me a summary, and return the extracted data in JSON format.");
  console.log(JSON.stringify(final, null, 1).slice(0, 1800));
  check("mandatory use case returns result", final && ["success", "partial"].includes(final.status), JSON.stringify(final));
  check("CLI actually ran (logs streamed)", events.some((e) => e.type === "log" && /GET http/.test(e.text)));
  check("JSON has real crawled titles", final.json && final.json.pages.some((p) => p.title === "Acme Widgets – Home"));
  check("robots.txt respected (secret page skipped)", final.json && final.json.skipped_by_robots_txt.some((u) => u.includes("secret")) && !final.json.pages.some((p) => p.url.includes("secret")));
  check("external domain not crawled", final.json && !final.json.pages.some((p) => p.url.includes("other.example")));
  check("partial status honestly flagged", final.status === "partial" && /robots/.test(final.text));
  check("injected page text never triggered any action (only data returned)", events.every((e) => e.type !== "command" || /crawler\.py/.test(e.text)) && events.filter((e) => e.type === "command").length === 1);
  check("valid JSON serialisable", (() => { try { JSON.parse(JSON.stringify(final.json)); return true; } catch { return false; } })());

  ({ final } = await chat("hello, what's the weather?"));
  check("unsupported request handled", final.status === "error" && /crawl/i.test(final.text), JSON.stringify(final));

  ({ final } = await chat("crawl notaurl and summarise"));
  check("invalid URL handled", final.status === "error", JSON.stringify(final));

  ({ final } = await chat("Crawl http://127.0.0.1:8765/missing-page and summarise"));
  check("404 -> honest failure", final.status === "error" && /failed/i.test(final.text), JSON.stringify(final));

  ({ final } = await chat("Crawl http://127.0.0.1:8765/slow and summarise"));
  console.log(JSON.stringify(final));
  check("hanging site -> error not fake success", final.status === "error", JSON.stringify(final));

  ({ final } = await chat("Crawl ftp://example.com and summarise"));
  check("non-http scheme refused", final.status === "error", JSON.stringify(final));

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
