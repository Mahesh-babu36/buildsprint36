#!/usr/bin/env python3
"""site-crawler: a small, polite, standard-library-only website crawler CLI.

Invoked by the CrawlChat backend (never through a shell). Writes a structured
JSON result file and communicates status through its exit code.

Exit codes:
  0  success      - all attempted pages fetched
  2  partial      - some pages fetched, some failed / were blocked
  3  failed       - nothing could be fetched
  4  invalid args / blocked target (private address, bad scheme)
"""
import argparse, ipaddress, json, socket, sys, time, urllib.error, urllib.request
from collections import deque
from html.parser import HTMLParser
from urllib.parse import urljoin, urldefrag, urlparse
from urllib.robotparser import RobotFileParser

MAX_BYTES = 1_000_000
UA = "CrawlChatBot/1.0 (+educational; respects robots.txt)"


class Blocked(Exception):
    pass


def check_host(host, allow_private):
    """Resolve host and refuse private / loopback / link-local targets (SSRF guard)."""
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror as e:
        raise Blocked(f"DNS lookup failed for {host}: {e}")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if not allow_private and (ip.is_private or ip.is_loopback or ip.is_link_local
                                  or ip.is_reserved or ip.is_multicast or ip.is_unspecified):
            raise Blocked(f"{host} resolves to a non-public address ({ip})")


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, allow_private):
        self.allow_private = allow_private

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        p = urlparse(newurl)
        if p.scheme not in ("http", "https"):
            raise Blocked(f"redirect to unsupported scheme {p.scheme}")
        check_host(p.hostname, self.allow_private)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class PageParser(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "template"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title, self.desc, self.lang = "", "", ""
        self.headings, self.links, self.paras = [], [], []
        self._stack, self._buf, self._skip = [], [], 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "html":
            self.lang = a.get("lang", "") or ""
        if tag in self.SKIP:
            self._skip += 1
        if tag == "meta" and (a.get("name", "").lower() == "description"):
            self.desc = (a.get("content") or "").strip()
        if tag == "a" and a.get("href"):
            self.links.append(a["href"])
        if tag in ("title", "h1", "h2", "h3", "p", "li"):
            self._stack.append(tag)
            self._buf = []

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip:
            self._skip -= 1
        if self._stack and self._stack[-1] == tag:
            self._stack.pop()
            text = " ".join("".join(self._buf).split())
            self._buf = []
            if not text:
                return
            if tag == "title":
                self.title = text
            elif tag in ("h1", "h2", "h3"):
                self.headings.append({"level": int(tag[1]), "text": text[:200]})
            elif len(text) > 40:
                self.paras.append(text[:400])

    def handle_data(self, data):
        if self._stack and not self._skip:
            self._buf.append(data)


def fetch(url, opener, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "text/html"})
    with opener.open(req, timeout=timeout) as r:
        ctype = r.headers.get("Content-Type", "")
        if "html" not in ctype.lower():
            raise ValueError(f"unsupported content type: {ctype or 'unknown'}")
        raw = r.read(MAX_BYTES + 1)[:MAX_BYTES]
        charset = r.headers.get_content_charset() or "utf-8"
        return r.status, raw.decode(charset, errors="replace"), r.geturl()


def main():
    ap = argparse.ArgumentParser(description="Polite same-domain website crawler")
    ap.add_argument("--url", required=True)
    ap.add_argument("--out", required=True, help="path of JSON result file")
    ap.add_argument("--max-pages", type=int, default=8)
    ap.add_argument("--depth", type=int, default=1)
    ap.add_argument("--timeout", type=int, default=10, help="per-request seconds")
    ap.add_argument("--delay", type=float, default=0.5, help="seconds between requests")
    ap.add_argument("--allow-private", action="store_true", help="DEV ONLY: allow private IPs")
    args = ap.parse_args()

    max_pages = max(1, min(args.max_pages, 25))
    depth = max(0, min(args.depth, 3))
    result = {"tool": "site-crawler", "start_url": args.url, "status": "failed",
              "pages": [], "errors": [], "robots_blocked": [], "stats": {}}
    t0 = time.time()

    def finish(code):
        result["stats"] = {"pages_fetched": len(result["pages"]),
                           "errors": len(result["errors"]),
                           "duration_seconds": round(time.time() - t0, 2),
                           "max_pages": max_pages, "max_depth": depth}
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"[crawler] status={result['status']} pages={len(result['pages'])} "
              f"errors={len(result['errors'])}", flush=True)
        sys.exit(code)

    p = urlparse(args.url)
    if p.scheme not in ("http", "https") or not p.hostname:
        result["errors"].append({"url": args.url, "error": "only http/https URLs are allowed"})
        finish(4)
    try:
        check_host(p.hostname, args.allow_private)
    except Blocked as e:
        result["errors"].append({"url": args.url, "error": str(e)})
        finish(4)

    opener = urllib.request.build_opener(SafeRedirect(args.allow_private))
    origin = f"{p.scheme}://{p.netloc}"
    robots = RobotFileParser()
    try:
        req = urllib.request.Request(origin + "/robots.txt", headers={"User-Agent": UA})
        with opener.open(req, timeout=args.timeout) as r:
            robots.parse(r.read(200_000).decode("utf-8", "replace").splitlines())
        print("[crawler] robots.txt loaded", flush=True)
    except urllib.error.HTTPError:
        robots.parse([])  # no robots.txt -> allowed
        print("[crawler] no robots.txt (allowed)", flush=True)
    except Exception as e:
        robots.parse([])
        print(f"[crawler] robots.txt unavailable: {e}", flush=True)

    seen = {urldefrag(args.url)[0]}
    queue = deque([(urldefrag(args.url)[0], 0)])
    while queue and len(result["pages"]) + len(result["errors"]) < max_pages:
        url, d = queue.popleft()
        if not robots.can_fetch(UA, url):
            result["robots_blocked"].append(url)
            print(f"[crawler] skipped (robots.txt): {url}", flush=True)
            continue
        try:
            print(f"[crawler] GET {url} (depth {d})", flush=True)
            status, html, final = fetch(url, opener, args.timeout)
            pp = PageParser()
            pp.feed(html)
            text_words = sum(len(x.split()) for x in pp.paras)
            result["pages"].append({
                "url": final, "http_status": status, "depth": d,
                "title": pp.title, "meta_description": pp.desc, "language": pp.lang,
                "headings": pp.headings[:15], "key_paragraphs": pp.paras[:6],
                "link_count": len(pp.links), "approx_word_count": text_words})
            if d < depth:
                for href in pp.links:
                    nxt = urldefrag(urljoin(final, href))[0]
                    q = urlparse(nxt)
                    if q.scheme in ("http", "https") and q.netloc == p.netloc and nxt not in seen:
                        seen.add(nxt)
                        queue.append((nxt, d + 1))
        except Blocked as e:
            result["errors"].append({"url": url, "error": str(e)})
        except urllib.error.HTTPError as e:
            result["errors"].append({"url": url, "error": f"HTTP {e.code}"})
        except Exception as e:
            result["errors"].append({"url": url, "error": f"{type(e).__name__}: {e}"})
        time.sleep(args.delay)

    if result["pages"] and not result["errors"] and not result["robots_blocked"]:
        result["status"] = "success"
        finish(0)
    elif result["pages"]:
        result["status"] = "partial"
        finish(2)
    else:
        if result["robots_blocked"] and not result["errors"]:
            result["errors"].append({"url": args.url, "error": "disallowed by robots.txt"})
        result["status"] = "failed"
        finish(3)


if __name__ == "__main__":
    main()
